import json
import sys
from pathlib import Path
import os

DAY_NAMES = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]

from src.timetabling.solver_cp_sat import SolveConfig, solve_instance
from src.timetabling.itc2019_parser import parse_itc2019_xml_to_instance


def _summarize(result: dict) -> dict:
    if result.get("status") not in ("optimal", "feasible"):
        return {"status": result.get("status")}

    schedule = result.get("schedule", {}) or {}
    mode_counts = {"online": 0, "in_person": 0, "hybrid": 0}
    for v in schedule.values():
        m = (v or {}).get("mode")
        if m in mode_counts:
            mode_counts[m] += 1

    return {
        "status": result.get("status"),
        "objectives": result.get("objectives", {}),
        "counts": {
            "n_classes": len(schedule),
            "n_students": len(result.get("students", {}) or {}),
        },
        "mode_counts": mode_counts,
    }


def _minutes_to_hhmm(m: int) -> str:
    h = int(m) // 60
    mm = int(m) % 60
    return f"{h:02d}:{mm:02d}"


def _decode_days(days: str) -> str:
    # ITC XML uses a 7-char string like 1000000 for Mon..Sun.
    s = (days or "").strip()
    if len(s) != 7 or any(c not in "01" for c in s):
        return "?"
    out = [DAY_NAMES[i] for i, c in enumerate(s) if c == "1"]
    return ",".join(out) if out else "?"


def _build_class_to_course(data: dict) -> dict:
    # Best-effort: map class_id -> module/course id based on module->config->subpart->class_ids.
    out: dict = {}
    for mod in data.get("modules", []) or []:
        mid = str(mod.get("id", ""))
        for cfg in mod.get("configs", []) or []:
            for sp in cfg.get("subparts", []) or []:
                for cid in sp.get("class_ids", []) or []:
                    out[str(cid)] = mid
    return out


def _print_examiner_output(*, instance_data: dict, result: dict, output_path: Path | None) -> None:
    # Summary section
    schedule = result.get("schedule", {}) or {}
    students = result.get("students", {}) or {}
    objectives = result.get("objectives", {}) or {}
    mode_counts = {"in_person": 0, "hybrid": 0, "online": 0}
    for v in schedule.values():
        m = (v or {}).get("mode")
        if m in mode_counts:
            mode_counts[m] += 1

    print("\n=== SUMMARY ===")
    print(f"Status: {result.get('status')}")
    print(f"Number of classes: {len(schedule)}")
    print(f"Number of students: {len(students)}")
    print(
        "Mode counts: "
        f"in_person={mode_counts['in_person']} | hybrid={mode_counts['hybrid']} | online={mode_counts['online']}"
    )
    print(
        "Objectives: "
        f"z1_electives={objectives.get('z1_electives', 0)} | "
        f"z2_mode={objectives.get('z2_mode', 0)} | "
        f"z3_clashes={objectives.get('z3_clashes', 0)} | "
        f"z4_online={objectives.get('z4_online', 0)} | "
        f"z5_late={objectives.get('z5_late', 0)}"
    )

    if output_path is not None:
        print(f"Full timetable saved in JSON: {output_path}")
    else:
        print("Full timetable is available in the JSON output printed by this program (or pass an output file path).")

    # Sample timetable table (first 10 classes)
    time_meta = (instance_data.get("time_meta", {}) or {})
    class_to_course = _build_class_to_course(instance_data)

    rows = []
    for cid, entry in schedule.items():
        if not entry:
            continue
        tid = entry.get("time")
        meta = time_meta.get(int(tid)) if tid is not None and str(tid).isdigit() else None
        days = _decode_days(meta.get("days")) if isinstance(meta, dict) else "?"
        start_min = int(meta.get("start_min")) if isinstance(meta, dict) else -1
        length_min = int(meta.get("length_min")) if isinstance(meta, dict) else -1
        start = _minutes_to_hhmm(start_min) if start_min >= 0 else "?"
        end = _minutes_to_hhmm(start_min + length_min) if start_min >= 0 and length_min >= 0 else "?"

        rows.append(
            {
                "class": str(cid),
                "course": str(class_to_course.get(str(cid), "-")),
                "day": days,
                "start": start,
                "end": end,
                "room": str(entry.get("room", "")),
                "mode": str(entry.get("mode", "")),
                "_sort": (days, start_min if start_min >= 0 else 10**9, str(cid)),
            }
        )

    rows.sort(key=lambda r: r["_sort"])
    rows = rows[:10]

    print("\n=== TIMETABLE SAMPLE (first 10 classes) ===")
    headers = ["Class ID", "Course", "Day", "Start", "End", "Room", "Mode"]
    data_rows = [[r["class"], r["course"], r["day"], r["start"], r["end"], r["room"], r["mode"]] for r in rows]
    col_widths = [len(h) for h in headers]
    for dr in data_rows:
        for i, cell in enumerate(dr):
            col_widths[i] = max(col_widths[i], len(str(cell)))

    def fmt_row(cells: list[str]) -> str:
        return " | ".join(str(c).ljust(col_widths[i]) for i, c in enumerate(cells))

    print(fmt_row(headers))
    print("-+-".join("-" * w for w in col_widths))
    for dr in data_rows:
        print(fmt_row([str(x) for x in dr]))


def main() -> int:
    if len(sys.argv) not in (2, 3):
        print("Usage: python -m src.run_solver <instance.json|instance.xml> [full_output.json]")
        return 2

    instance_path = Path(sys.argv[1])
    output_path = Path(sys.argv[2]) if len(sys.argv) == 3 else None

    if instance_path.suffix.lower() == ".xml":
        data = parse_itc2019_xml_to_instance(instance_path)
    else:
        data = json.loads(instance_path.read_text(encoding="utf-8"))

    cfg = SolveConfig(
        max_time_seconds=float(os.environ.get("BASE_TIME", "10.0")),
        lns_iterations=int(os.environ.get("LNS_ITERS", "0")),
        lns_iteration_time_seconds=float(os.environ.get("LNS_TIME", "1.0")),
        lns_destroy_fraction=float(os.environ.get("LNS_DESTROY", "0.2")),
        random_seed=int(os.environ.get("LNS_SEED", "0")),
    )

    result = solve_instance(data, cfg)

    # Make the output JSON self-contained for simple demos (e.g., static HTML viewing).
    # This does not change solver logic; it only attaches metadata already present in the parsed instance.
    if isinstance(data, dict):
        if "time_meta" in data and "time_meta" not in result:
            result["time_meta"] = data.get("time_meta")
        if "class_to_course" not in result:
            result["class_to_course"] = _build_class_to_course(data)

    if output_path is not None:
        output_path.write_text(json.dumps(result, indent=2, sort_keys=True), encoding="utf-8")

    if result.get("status") in ("optimal", "feasible"):
        _print_examiner_output(instance_data=data, result=result, output_path=output_path)

    # Default printing: compact summary for XML (ITC instances can be huge), full for JSON.
    if instance_path.suffix.lower() == ".xml":
        print(json.dumps(_summarize(result), indent=2, sort_keys=True))
    else:
        print(json.dumps(result, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
