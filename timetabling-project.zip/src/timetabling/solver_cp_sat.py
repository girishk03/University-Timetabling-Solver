from __future__ import annotations

from dataclasses import dataclass
import random
import time
from typing import Any, Dict, Iterable, List, Tuple

from ortools.sat.python import cp_model


ONLINE_ROOM_ID = "__online__"


@dataclass(frozen=True)
class SolveConfig:
    max_time_seconds: float = 10.0
    lns_iterations: int = 0
    lns_iteration_time_seconds: float = 1.0
    lns_destroy_fraction: float = 0.2
    random_seed: int = 0


def _as_list(x: Any) -> List[Any]:
    if x is None:
        return []
    if isinstance(x, list):
        return x
    raise TypeError(f"Expected list, got {type(x)}")


def _objective_tuple(obj: Dict[str, int]) -> Tuple[int, int, int, int, int]:
    return (
        int(obj.get("z1_electives", 0)),
        int(obj.get("z2_mode", 0)),
        int(obj.get("z3_clashes", 0)),
        int(obj.get("z4_online", 0)),
        int(obj.get("z5_late", 0)),
    )


def _better(a: Tuple[int, int, int, int, int], b: Tuple[int, int, int, int, int]) -> bool:
    # Lexicographic: maximize z1, then minimize z2, then minimize z3, then minimize z4, then minimize z5.
    if a[0] != b[0]:
        return a[0] > b[0]
    if a[1] != b[1]:
        return a[1] < b[1]
    if a[2] != b[2]:
        return a[2] < b[2]
    if a[3] != b[3]:
        return a[3] < b[3]
    return a[4] < b[4]


def _implies(model: cp_model.CpModel, a: cp_model.IntVar, b: cp_model.IntVar) -> None:
    model.add(a <= b)


def _apply_fixed_schedule(
    model: cp_model.CpModel,
    fixed_schedule: Dict[str, Dict[str, Any]],
    x_phys: Dict[Tuple[str, str, int], cp_model.IntVar],
    x_onl: Dict[Tuple[str, int], cp_model.IntVar],
    y_time: Dict[Tuple[str, int], cp_model.IntVar],
    y_phys: Dict[Tuple[str, int], cp_model.IntVar],
    y_onl: Dict[Tuple[str, int], cp_model.IntVar],
) -> None:
    for cid, fix in fixed_schedule.items():
        if not fix:
            continue
        fixed_time = int(fix["time"])
        mode = str(fix.get("mode", "online"))
        room = str(fix.get("room", ONLINE_ROOM_ID))
        phys = 1 if mode in ("in_person", "hybrid") else 0
        onl = 1 if mode in ("online", "hybrid") else 0

        for (cc, t), var in y_time.items():
            if cc == cid:
                model.add(var == (1 if int(t) == fixed_time else 0))

        for (cc, t), var in y_phys.items():
            if cc == cid:
                model.add(var == (phys if int(t) == fixed_time else 0))

        for (cc, t), var in y_onl.items():
            if cc == cid:
                model.add(var == (onl if int(t) == fixed_time else 0))

        for (cc, r, t), var in x_phys.items():
            if cc != cid:
                continue
            if int(t) == fixed_time and phys == 1 and str(r) == room:
                model.add(var == 1)
            else:
                model.add(var == 0)

        for (cc, t), var in x_onl.items():
            if cc == cid:
                model.add(var == (onl if int(t) == fixed_time else 0))


def _cfg_without_lns(cfg: SolveConfig, *, max_time_seconds: float) -> SolveConfig:
    return SolveConfig(
        max_time_seconds=float(max_time_seconds),
        lns_iterations=0,
        lns_iteration_time_seconds=float(cfg.lns_iteration_time_seconds),
        lns_destroy_fraction=float(cfg.lns_destroy_fraction),
        random_seed=int(cfg.random_seed),
    )


def solve_instance_lns(data: Dict[str, Any], cfg: SolveConfig) -> Dict[str, Any]:
    rng = random.Random(int(cfg.random_seed))

    deadline = time.time() + float(cfg.max_time_seconds)

    def _time_left() -> float:
        return max(0.0, deadline - time.time())

    # Baseline solve gets almost all of the global budget so we reliably obtain an incumbent.
    # Reserve a small slice of time for LNS iterations.
    total_budget = float(cfg.max_time_seconds)
    reserve = min(5.0, 0.15 * total_budget)
    base_budget = max(5.0, total_budget - reserve)
    base_budget = min(base_budget, _time_left())

    base_cfg = _cfg_without_lns(cfg, max_time_seconds=float(base_budget))
    best = solve_instance(data, base_cfg)
    if best.get("status") == "unknown":
        # Be defensive: if the baseline times out (should be rare for small instances),
        # retry once with a larger budget so LNS always has an incumbent to start from.
        retry_budget = _time_left()
        if retry_budget > 0:
            retry_cfg = _cfg_without_lns(cfg, max_time_seconds=float(retry_budget))
            best = solve_instance(data, retry_cfg)
    if best.get("status") not in ("optimal", "feasible"):
        return best

    best_obj = _objective_tuple(best.get("objectives", {}))
    best_schedule = best.get("schedule", {}) or {}

    classes: List[Dict[str, Any]] = data.get("classes", [])
    class_ids = [c["id"] for c in classes if "id" in c]
    if not class_ids:
        return best

    iterations = max(0, int(cfg.lns_iterations))
    destroy_fraction = float(cfg.lns_destroy_fraction)
    iter_time = float(cfg.lns_iteration_time_seconds)

    for _ in range(iterations):
        remaining = _time_left()
        if remaining <= 0:
            break
        k = int(max(1, round(destroy_fraction * len(class_ids))))
        destroyed = set(rng.sample(class_ids, k=min(k, len(class_ids))))

        fixed_schedule = {cid: best_schedule.get(cid) for cid in class_ids if cid not in destroyed}

        # Respect the global wall-clock budget.
        iter_cfg = _cfg_without_lns(cfg, max_time_seconds=min(iter_time, remaining))
        candidate = solve_instance(data, iter_cfg, fixed_schedule=fixed_schedule)
        if candidate.get("status") not in ("optimal", "feasible"):
            continue
        cand_obj = _objective_tuple(candidate.get("objectives", {}))
        if _better(cand_obj, best_obj):
            best = candidate
            best_obj = cand_obj
            best_schedule = best.get("schedule", {}) or {}

    return best


def solve_instance(
    data: Dict[str, Any],
    cfg: SolveConfig | None = None,
    fixed_schedule: Dict[str, Dict[str, Any]] | None = None,
) -> Dict[str, Any]:
    cfg = cfg or SolveConfig()

    if cfg.lns_iterations > 0 and fixed_schedule is None:
        return solve_instance_lns(data, cfg)

    rooms: Dict[str, Dict[str, Any]] = data["rooms"]
    times: List[int] = [int(t) for t in data["times"]]
    time_start_min: Dict[int, int] = {int(k): int(v) for k, v in (data.get("time_start_min", {}) or {}).items()}
    classes: List[Dict[str, Any]] = data["classes"]
    modules: List[Dict[str, Any]] = data.get("modules", [])
    students: List[Dict[str, Any]] = data.get("students", [])

    room_cap: Dict[str, int] = {rid: int(r.get("cap", 0)) for rid, r in rooms.items()}
    room_hybrid_ok: Dict[str, bool] = {rid: bool(r.get("hybrid", False)) for rid, r in rooms.items()}
    room_hybrid_ok[ONLINE_ROOM_ID] = True
    room_cap.setdefault(ONLINE_ROOM_ID, 10**9)

    class_by_id: Dict[str, Dict[str, Any]] = {c["id"]: c for c in classes}

    model = cp_model.CpModel()

    # Scheduling vars
    # x_phys[(c,r,t)] for physical rooms only
    x_phys: Dict[Tuple[str, str, int], cp_model.IntVar] = {}
    # x_onl[(c,t)] for optional online stream
    x_onl: Dict[Tuple[str, int], cp_model.IntVar] = {}

    y_time: Dict[Tuple[str, int], cp_model.IntVar] = {}
    y_phys: Dict[Tuple[str, int], cp_model.IntVar] = {}
    y_onl: Dict[Tuple[str, int], cp_model.IntVar] = {}

    # Delivery-mode indicator vars per (class,time)
    # online_only=1 if delivered online but not physically
    online_only: Dict[Tuple[str, int], cp_model.IntVar] = {}
    # hybrid=1 if delivered both physically and online
    hybrid: Dict[Tuple[str, int], cp_model.IntVar] = {}

    for c in classes:
        cid = c["id"]
        allowed_times = [int(t) for t in c.get("allowed_times", times)]
        allowed_rooms = list(c.get("allowed_rooms", list(rooms.keys())))

        for t in allowed_times:
            y_time[(cid, t)] = model.new_bool_var(f"y_time[{cid},{t}]")
            y_phys[(cid, t)] = model.new_bool_var(f"y_phys[{cid},{t}]")
            y_onl[(cid, t)] = model.new_bool_var(f"y_onl[{cid},{t}]")

            online_only[(cid, t)] = model.new_bool_var(f"online_only[{cid},{t}]")
            hybrid[(cid, t)] = model.new_bool_var(f"hybrid[{cid},{t}]")

            # Online stream is per-time.
            if ONLINE_ROOM_ID in allowed_rooms:
                x_onl[(cid, t)] = model.new_bool_var(f"x_onl[{cid},{t}]")
                model.add(y_onl[(cid, t)] == x_onl[(cid, t)])
            else:
                model.add(y_onl[(cid, t)] == 0)

            # Physical/online can only exist if the class is at that time.
            model.add(y_phys[(cid, t)] <= y_time[(cid, t)])
            model.add(y_onl[(cid, t)] <= y_time[(cid, t)])

            # If the class is at time t, it must be delivered either physically or online (or both).
            model.add(y_phys[(cid, t)] + y_onl[(cid, t)] >= y_time[(cid, t)])

            # Mode indicators
            # hybrid == y_phys AND y_onl
            _implies(model, hybrid[(cid, t)], y_phys[(cid, t)])
            _implies(model, hybrid[(cid, t)], y_onl[(cid, t)])
            model.add(hybrid[(cid, t)] >= y_phys[(cid, t)] + y_onl[(cid, t)] - 1)

            # online_only == y_onl AND (NOT y_phys)
            _implies(model, online_only[(cid, t)], y_onl[(cid, t)])
            model.add(online_only[(cid, t)] <= 1 - y_phys[(cid, t)])
            model.add(online_only[(cid, t)] >= y_onl[(cid, t)] - y_phys[(cid, t)])

        for r in allowed_rooms:
            if r == ONLINE_ROOM_ID:
                continue
            for t in allowed_times:
                x_phys[(cid, r, t)] = model.new_bool_var(f"x_phys[{cid},{r},{t}]")

        # The class happens at exactly one time.
        model.add(sum(y_time[(cid, t)] for t in allowed_times) == 1)

        # Link physical room selection to y_phys at each time.
        for t in allowed_times:
            phys_terms_t = [
                x_phys[(cid, r, t)]
                for r in allowed_rooms
                if r != ONLINE_ROOM_ID and (cid, r, t) in x_phys
            ]
            if phys_terms_t:
                model.add(sum(phys_terms_t) == y_phys[(cid, t)])
            else:
                model.add(y_phys[(cid, t)] == 0)

        # Hybrid rule: if a class is delivered both physically and online at time t, the physical room must be hybrid-capable.
        for t in allowed_times:
            phys_hybrid_terms = [
                x_phys[(cid, r, t)]
                for r in allowed_rooms
                if r != ONLINE_ROOM_ID and room_hybrid_ok.get(r, False) and (cid, r, t) in x_phys
            ]
            if phys_hybrid_terms:
                # y_onl <= sum(hybrid_room_selected) + (1 - y_phys)
                model.add(y_onl[(cid, t)] <= sum(phys_hybrid_terms) + (1 - y_phys[(cid, t)]))
            else:
                # If there is no hybrid-capable physical room, the class cannot be hybrid.
                model.add(y_onl[(cid, t)] + y_phys[(cid, t)] <= 1)

    if fixed_schedule:
        _apply_fixed_schedule(model, fixed_schedule, x_phys, x_onl, y_time, y_phys, y_onl)

    # Physical room clash
    for r in rooms.keys():
        if r == ONLINE_ROOM_ID:
            continue
        for t in times:
            model.add(
                sum(x_phys.get((c["id"], r, t), 0) for c in classes) <= 1
            )

    # Student/module variables
    module_by_id = {m["id"]: m for m in modules}

    n: Dict[Tuple[str, str], cp_model.IntVar] = {}
    mvar: Dict[Tuple[str, str, str], cp_model.IntVar] = {}
    a: Dict[Tuple[str, str, str, str, str], cp_model.IntVar] = {}

    alpha_inp: Dict[Tuple[str, str], cp_model.IntVar] = {}
    alpha_onl: Dict[Tuple[str, str], cp_model.IntVar] = {}
    tau: Dict[Tuple[str, str], cp_model.IntVar] = {}

    # Helper: for each class, which (k,f,p) it belongs to
    class_to_kfp: Dict[str, List[Tuple[str, str, str]]] = {cid: [] for cid in class_by_id.keys()}
    for k in modules:
        kid = k["id"]
        for f in k.get("configs", []):
            fid = f["id"]
            for p in f.get("subparts", []):
                pid = p["id"]
                for cid in p.get("class_ids", []):
                    if cid in class_to_kfp:
                        class_to_kfp[cid].append((kid, fid, pid))

    # Create variables and constraints
    for s in students:
        sid = s["id"]
        requested = set(_as_list(s.get("requested_modules")))
        compulsory = set(_as_list(s.get("compulsory_modules")))
        kcap = int(s.get("module_cap", len(requested) + len(compulsory)))
        pref = int(s.get("mode_pref", 0))

        # Module selection vars
        for kid in module_by_id.keys():
            n[(sid, kid)] = model.new_bool_var(f"n[{sid},{kid}]")
            if kid not in requested and kid not in compulsory:
                model.add(n[(sid, kid)] == 0)
            if kid in compulsory:
                model.add(n[(sid, kid)] == 1)

        model.add(sum(n[(sid, kid)] for kid in module_by_id.keys()) <= kcap)

        # Config selection
        for kid, k in module_by_id.items():
            cfgs = k.get("configs", [])
            if not cfgs:
                continue
            for f in cfgs:
                fid = f["id"]
                mvar[(sid, kid, fid)] = model.new_bool_var(f"m[{sid},{kid},{fid}]")

            model.add(sum(mvar[(sid, kid, f["id"])] for f in cfgs) == n[(sid, kid)])

            # For each subpart: pick exactly 1 class if config picked
            for f in cfgs:
                fid = f["id"]
                for p in f.get("subparts", []):
                    pid = p["id"]
                    class_ids = p.get("class_ids", [])
                    if not class_ids:
                        continue
                    for cid in class_ids:
                        a[(sid, kid, fid, pid, cid)] = model.new_bool_var(f"a[{sid},{kid},{fid},{pid},{cid}]")
                    model.add(
                        sum(a[(sid, kid, fid, pid, cid)] for cid in class_ids) == mvar[(sid, kid, fid)]
                    )

        # Attendance vars per class
        for c in classes:
            cid = c["id"]
            alpha_inp[(sid, cid)] = model.new_bool_var(f"alpha_inp[{sid},{cid}]")
            alpha_onl[(sid, cid)] = model.new_bool_var(f"alpha_onl[{sid},{cid}]")

            # If student is assigned to class cid in any (k,f,p) position, attend it.
            assign_terms: List[cp_model.IntVar] = []
            for (kid, fid, pid) in class_to_kfp.get(cid, []):
                key = (sid, kid, fid, pid, cid)
                if key in a:
                    assign_terms.append(a[key])

            if assign_terms:
                model.add(alpha_inp[(sid, cid)] + alpha_onl[(sid, cid)] == sum(assign_terms))
            else:
                model.add(alpha_inp[(sid, cid)] == 0)
                model.add(alpha_onl[(sid, cid)] == 0)

            # Can only attend online if class scheduled online at some time.
            onl_possible = [x_onl[(cid, t)] for (cc, t) in x_onl.keys() if cc == cid]
            phys_possible = [x_phys[(cid, r, t)] for (cc, r, t) in x_phys.keys() if cc == cid]
            if onl_possible:
                model.add(alpha_onl[(sid, cid)] <= sum(onl_possible))
            else:
                model.add(alpha_onl[(sid, cid)] == 0)
            if phys_possible:
                model.add(alpha_inp[(sid, cid)] <= sum(phys_possible))
            else:
                model.add(alpha_inp[(sid, cid)] == 0)

            # Mode deviation
            tau[(sid, cid)] = model.new_bool_var(f"tau[{sid},{cid}]")
            if pref == 1:
                model.add(tau[(sid, cid)] >= alpha_onl[(sid, cid)])
            elif pref == -1:
                model.add(tau[(sid, cid)] >= alpha_inp[(sid, cid)])
            else:
                model.add(tau[(sid, cid)] == 0)
            # tau can only be 1 if class is attended at all
            model.add(tau[(sid, cid)] <= alpha_inp[(sid, cid)] + alpha_onl[(sid, cid)])

    # Capacity constraints
    for c in classes:
        cid = c["id"]
        sub_cap = int(c.get("subscription", 10**9))
        model.add(
            sum(alpha_inp.get((s["id"], cid), 0) + alpha_onl.get((s["id"], cid), 0) for s in students) <= sub_cap
        )

        # Exact physical room capacity linking: sum in-person attendees <= sum cap(r) * x_phys[c,r,t]
        cap_terms: List[cp_model.LinearExpr] = []
        for (cc, r, t), var in x_phys.items():
            if cc != cid:
                continue
            cap_terms.append(int(room_cap.get(r, 0)) * var)
        inp_sum = sum(alpha_inp.get((s["id"], cid), 0) for s in students)
        if cap_terms:
            model.add(inp_sum <= sum(cap_terms))
        else:
            # No physical room option exists for this class => nobody can attend in-person.
            model.add(inp_sum == 0)

    # Student time clash soft penalty: slack per (student,time)
    slack: Dict[Tuple[str, int], cp_model.IntVar] = {}
    for s in students:
        sid = s["id"]
        for t in times:
            attending_at_t: List[cp_model.IntVar] = []
            for c in classes:
                cid = c["id"]
                if (cid, t) not in y_time:
                    continue
                # attending class implies it happens at that time
                # (because each class scheduled exactly once)
                attending = model.new_bool_var(f"att[{sid},{cid},{t}]")
                model.add(attending <= alpha_inp[(sid, cid)] + alpha_onl[(sid, cid)])
                model.add(attending <= y_time[(cid, t)])
                model.add(attending >= (alpha_inp[(sid, cid)] + alpha_onl[(sid, cid)]) + y_time[(cid, t)] - 1)
                attending_at_t.append(attending)

            slack[(sid, t)] = model.new_int_var(0, len(classes), f"slack[{sid},{t}]")
            if attending_at_t:
                # slack >= sum(attending) - 1
                model.add(slack[(sid, t)] >= sum(attending_at_t) - 1)
            else:
                model.add(slack[(sid, t)] == 0)

    # Lexicographic objectives via sequential solves
    solver = cp_model.CpSolver()
    if cfg.random_seed:
        solver.parameters.random_seed = int(cfg.random_seed)
    start_time = time.time()

    # Late class constants (18:00 = 1080 minutes). If time metadata is missing, we treat all as not-late.
    late_time: Dict[int, int] = {}
    for t in times:
        start_min = int(time_start_min.get(int(t), -1))
        late_time[int(t)] = 1 if start_min >= 18 * 60 and start_min >= 0 else 0

    def _has_solution() -> bool:
        try:
            return len(solver.response_proto.solution) > 0
        except Exception:
            return False

    def _remaining_time() -> float:
        return float(cfg.max_time_seconds) - (time.time() - start_time)

    def _fix_objective_value(obj: cp_model.LinearExpr | int, value: int) -> None:
        # Avoid adding model.add(True/False) when obj is a plain int.
        if isinstance(obj, int):
            return
        model.add(obj == value)

    def _solve_with_objective(obj: cp_model.LinearExpr | int, sense: str) -> Tuple[cp_model.CpSolverStatus, int]:
        remaining = _remaining_time()
        if remaining <= 0:
            return cp_model.UNKNOWN, 0
        solver.parameters.max_time_in_seconds = float(max(0.001, remaining))

        if isinstance(obj, int):
            # Constant objective: just find any feasible solution.
            status = solver.solve(model)
            if status in (cp_model.OPTIMAL, cp_model.FEASIBLE):
                return status, int(obj)
            return status, 0

        if sense == "max":
            model.maximize(obj)
        else:
            model.minimize(obj)
        status = solver.solve(model)
        if status in (cp_model.OPTIMAL, cp_model.FEASIBLE):
            return status, int(solver.objective_value)
        return status, 0

    # z1: elective modules satisfied
    elective_terms: List[cp_model.IntVar] = []
    for s in students:
        sid = s["id"]
        electives = set(_as_list(s.get("requested_modules"))) - set(_as_list(s.get("compulsory_modules")))
        for kid in electives:
            if (sid, kid) in n:
                elective_terms.append(n[(sid, kid)])

    z1_expr = sum(elective_terms) if elective_terms else 0
    status, z1_star = _solve_with_objective(z1_expr, "max")
    stop_after_stage = False
    if status == cp_model.UNKNOWN:
        if not _has_solution():
            return {"status": "unknown"}
        status = cp_model.FEASIBLE
        stop_after_stage = True
    elif status not in (cp_model.OPTIMAL, cp_model.FEASIBLE):
        return {"status": "infeasible"}
    else:
        _fix_objective_value(z1_expr, z1_star)

    if not stop_after_stage:
        # z2: mode deviations
        z2_expr = sum(tau.values()) if tau else 0
        status, z2_star = _solve_with_objective(z2_expr, "min")
        if status == cp_model.UNKNOWN:
            if not _has_solution():
                return {"status": "unknown"}
            status = cp_model.FEASIBLE
            stop_after_stage = True
        elif status not in (cp_model.OPTIMAL, cp_model.FEASIBLE):
            return {"status": "infeasible"}
        else:
            _fix_objective_value(z2_expr, z2_star)

    if not stop_after_stage:
        # z3: student time clashes
        z3_expr = sum(slack.values()) if slack else 0
        status, z3_star = _solve_with_objective(z3_expr, "min")
        if status == cp_model.UNKNOWN:
            if not _has_solution():
                return {"status": "unknown"}
            status = cp_model.FEASIBLE
            stop_after_stage = True
        elif status not in (cp_model.OPTIMAL, cp_model.FEASIBLE):
            return {"status": "infeasible"}
        else:
            _fix_objective_value(z3_expr, z3_star)

    if not stop_after_stage:
        # z4: discourage online delivery (online > hybrid > in-person)
        # We keep it integer-only by scaling:
        # - online-only: 2
        # - hybrid: 1
        # - in-person: 0
        z4_expr = 0
        if online_only or hybrid:
            z4_expr = 2 * sum(online_only.values()) + sum(hybrid.values())

        status, z4_star = _solve_with_objective(z4_expr, "min")
        if status == cp_model.UNKNOWN:
            if not _has_solution():
                return {"status": "unknown"}
            status = cp_model.FEASIBLE
        elif status not in (cp_model.OPTIMAL, cp_model.FEASIBLE):
            return {"status": "infeasible"}
        else:
            _fix_objective_value(z4_expr, z4_star)

    if not stop_after_stage:
        # z5: discourage late classes (start after 18:00)
        z5_expr = 0
        if late_time:
            z5_terms: List[cp_model.LinearExpr] = []
            for (cid, t), var in y_time.items():
                if int(t) in late_time and late_time[int(t)] == 1:
                    z5_terms.append(var)
            z5_expr = sum(z5_terms) if z5_terms else 0

        status, z5_star = _solve_with_objective(z5_expr, "min")
        if status == cp_model.UNKNOWN:
            if not _has_solution():
                return {"status": "unknown"}
            status = cp_model.FEASIBLE
        elif status not in (cp_model.OPTIMAL, cp_model.FEASIBLE):
            return {"status": "infeasible"}
        else:
            _fix_objective_value(z5_expr, z5_star)

    # Extract solution
    schedule: Dict[str, Dict[str, Any]] = {}
    for c in classes:
        cid = c["id"]
        assigned_time = None
        for (cc, t), var in y_time.items():
            if cc == cid and solver.value(var) == 1:
                assigned_time = t
                break

        if assigned_time is None:
            schedule[cid] = {}
            continue

        phys_room = None
        for (cc, r, t), var in x_phys.items():
            if cc == cid and t == assigned_time and solver.value(var) == 1:
                phys_room = r
                break

        onl = int(solver.value(y_onl[(cid, assigned_time)]))
        phys = int(solver.value(y_phys[(cid, assigned_time)]))
        if phys == 1 and onl == 1:
            schedule[cid] = {"room": phys_room, "time": assigned_time, "mode": "hybrid"}
        elif phys == 1:
            schedule[cid] = {"room": phys_room, "time": assigned_time, "mode": "in_person"}
        else:
            schedule[cid] = {"room": ONLINE_ROOM_ID, "time": assigned_time, "mode": "online"}

    student_out: Dict[str, Any] = {}
    for s in students:
        sid = s["id"]
        taken_modules = [kid for kid in module_by_id.keys() if solver.value(n[(sid, kid)]) == 1]
        attended = {}
        for c in classes:
            cid = c["id"]
            attended[cid] = {
                "in_person": int(solver.value(alpha_inp[(sid, cid)])),
                "online": int(solver.value(alpha_onl[(sid, cid)])),
                "mode_deviation": int(solver.value(tau[(sid, cid)])),
            }
        student_out[sid] = {
            "taken_modules": taken_modules,
            "attended": attended,
        }

    # Recompute objective values from the extracted solution to ensure consistency
    # even when some lexicographic stages were skipped due to time.
    z1_val = int(sum(solver.value(v) for v in elective_terms)) if elective_terms else 0
    z2_val = int(sum(solver.value(v) for v in tau.values())) if tau else 0
    z3_val = int(sum(solver.value(v) for v in slack.values())) if slack else 0
    z4_val = int(2 * sum(solver.value(v) for v in online_only.values()) + sum(solver.value(v) for v in hybrid.values()))
    z5_val = 0
    if late_time:
        z5_val = int(sum(solver.value(var) for (cid, t), var in y_time.items() if late_time.get(int(t), 0) == 1))

    return {
        "status": "optimal" if status == cp_model.OPTIMAL else "feasible",
        "objectives": {
            "z1_electives": z1_val,
            "z2_mode": z2_val,
            "z3_clashes": z3_val,
            "z4_online": z4_val,
            "z5_late": z5_val,
        },
        "schedule": schedule,
        "students": student_out,
    }
