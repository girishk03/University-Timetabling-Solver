

# University Timetabling Dashboard - Refinement Plan

## Overview
Polish your existing HTML/CSS/JavaScript timetabling dashboard to be examiner-grade quality while preserving all existing functionality and the JSON data flow.

---

## 1. UI/UX Improvements

### Layout & Visual Hierarchy
- **Refined header** with cleaner typography and subtle academic branding
- **Summary metrics redesign** - group related metrics into visual sections:
  - "Solution Status" card (status badge)
  - "Counts" section (classes, students breakdown)
  - "Objectives" section (z1-z5 metrics with visual indicators)
- **Improved card styling** with subtle shadows and better padding consistency

### Typography & Spacing
- Increase base font sizes slightly for readability
- Consistent spacing scale (8px, 12px, 16px, 24px)
- Better contrast for labels vs. values
- Academic-style section headers with subtle borders

### Color Refinements
- Keep the existing subtle palette (white/gray/blue)
- Add visual indicators for objective metrics:
  - Green for "good" values (z3_clashes = 0, z2_mode = 0)
  - Amber for "warning" values
  - Red highlight for z5_late > 0 (late evening penalty)
- **Late class highlighting** in table rows where start time > 17:00 (1020 minutes)

### Table Improvements
- Ensure sticky headers work correctly in all browsers
- Add subtle row hover states (already have this)
- Zebra striping refinement
- Column width optimization for the 7 columns

---

## 2. Performance Optimizations

### DOM Rendering
- Use **DocumentFragment** for batch table rendering instead of direct appendChild
- Pre-build HTML strings for large table updates
- Avoid layout thrashing by batching DOM reads/writes

### Search & Filter
- Add **debounce** (150ms) to search input to prevent excessive filtering
- Cache filtered results when only pagination changes
- Use requestAnimationFrame for smooth rendering

### Initial Load
- Show loading state while processing JSON
- Render summary first, then table (progressive rendering)

---

## 3. Usability Enhancements

### File Upload
- **Clearer upload section** with:
  - Drag-and-drop zone with visual feedback
  - File type validation (.json only)
  - File size indicator
  - Clear "Browse" button styling

### Empty & Error States
- **No data state**: Friendly message with upload instructions
- **Error state**: Red-bordered message with specific error details
- **No results state**: "No classes match your filters" with reset button
- **Loading state**: Spinner or skeleton during JSON processing

### Late Class Highlighting
- Visual indicator (amber/orange background) for classes starting after 17:00
- Add tooltip explaining "Late evening class"
- Option to filter to show only late classes

### Filter Improvements
- Add "Clear all filters" button when filters are active
- Show active filter count badge
- Instant filter feedback with result count

---

## 4. Code Quality Improvements

### JavaScript Refactoring
- **Organize into clear sections** with comment headers:
  ```
  // ======== CONSTANTS ========
  // ======== UTILITIES ========
  // ======== RENDERING ========
  // ======== FILTERS ========
  // ======== EVENT HANDLERS ========
  // ======== INITIALIZATION ========
  ```
- Extract repeated logic into named functions
- Add JSDoc-style comments for main functions
- Use const/let consistently (no var)

### Event Listener Cleanup
- Consolidate event listeners into single initialization function
- Use event delegation for table row interactions
- Prevent duplicate listener attachment

### Error Handling
- Wrap JSON parsing in try/catch with user-friendly messages
- Validate JSON schema before rendering
- Handle missing/malformed data gracefully

---

## 5. Deliverables

The refined dashboard will include:
- **Single HTML file** with embedded CSS and JavaScript (keeping your structure)
- **All existing features preserved**: JSON loading, search, filters, room selector, mode selector, summary metrics, timetable table
- **Professional academic appearance** suitable for examination
- **Smooth performance** for 150-300 row datasets
- **Clear code organization** with examiner-friendly comments

---

## Technical Notes
- No backend or external dependencies added
- No changes to JSON schema or data flow
- Works with double-click opening or file chooser
- Maintains compatibility with student_names.json and course_names.json external files

